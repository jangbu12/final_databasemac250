from pathlib import Path
import sqlite3

DATABASE = Path(__file__).resolve().parent / "student individual university system.db"
if not DATABASE.is_file():
    raise FileNotFoundError(f"Missing database: {DATABASE}")
with sqlite3.connect(DATABASE.as_uri() + "?mode=ro", uri=True) as db:
    tables = [r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")]
    print("Database:", DATABASE)
    print("Tables:", tables)
    for row in db.execute("SELECT StudentID, FirstName, LastName FROM Students"):
        print(*row)
